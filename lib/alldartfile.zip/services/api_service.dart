import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = "http://50.50.50.1/api";

  // =================================================
  // BOOTSTRAP (الأساس – يستخدمه SplashScreen)
  // =================================================
 static Future<Map<String, dynamic>> bootstrap({String? token}) async {
  final headers = {"Accept": "application/json"};

  if (token != null && token.isNotEmpty) {
    headers["X-Auth-Token"] = token;
  }

  final res = await http.get(
    Uri.parse("$baseUrl/bootstrap"),
    headers: headers,
  );

  return json.decode(res.body);
}

static Future<Map<String, dynamic>> getStatusAnonymous() async {
  final res = await http.get(
    Uri.parse("$baseUrl/status.php"),
    headers: {"Accept": "application/json"},
  );
  return json.decode(res.body);
}

  // =================================================
  // SUBSCRIPTION STATUS (بعد تسجيل الدخول فقط)
  // =================================================
  static Future<Map<String, dynamic>> getStatus(String token) async {
    final res = await http.get(
      Uri.parse("$baseUrl/status.php"),
      headers: {
        "X-Auth-Token": token,
        "Accept": "application/json",
      },
    );

    return json.decode(res.body);
  }

  // =================================================
  // LOGIN
  // =================================================
  static Future<Map<String, dynamic>> login({
    required String username,
    required String password,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/login"),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: json.encode({
        "username": username,
        "password": password,
      }),
    );

    return json.decode(res.body);
  }

  // =================================================
  // CREATE ACCOUNT
  // =================================================
 static Future<Map<String, dynamic>> createAccount({
  required int subscriberId,
  required String username,
  required String password,
}) async {
  final res = await http.post(
    Uri.parse("$baseUrl/create-account"),
    headers: {
      "Content-Type": "application/json",
      "Accept": "application/json",
    },
    body: jsonEncode({
      "subscriber_id": subscriberId,
      "username": username,
      "password": password,
    }),
  );

  return jsonDecode(res.body);
}

  // =================================================
  // NOTIFICATIONS
  // =================================================
  static Future<Map<String, dynamic>> getNotifications(String token) async {
    final res = await http.get(
      Uri.parse("$baseUrl/notifications"),
      headers: {
        "X-Auth-Token": token,
        "Accept": "application/json",
      },
    );

    return json.decode(res.body);
  }

  // =================================================
  // CREATE TICKET
  // =================================================
  static Future<Map<String, dynamic>> createTicket({
    required String token,
    required String type,
    required String message,
  }) async {
    final res = await http.post(
      Uri.parse("$baseUrl/tickets/create"),
      headers: {
        "X-Auth-Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: json.encode({
        "type": type,
        "message": message,
      }),
    );

    return json.decode(res.body);
  }

  // =================================================
  // SAVE FCM TOKEN
  // =================================================
  static Future<void> saveFcmToken({
    required String token,
    required String fcmToken,
  }) async {
    await http.post(
      Uri.parse("$baseUrl/register_fcm.php"),
      headers: {
        "X-Auth-Token": token,
      },
      body: {
        "fcm_token": fcmToken,
        "device": "android",
      },
    );
  }

  // =================================================
  // LOGOUT
  // =================================================
  static Future<void> logout(String token) async {
    await http.post(
      Uri.parse("$baseUrl/logout.php"),
      headers: {
        "X-Auth-Token": token,
        "Accept": "application/json",
      },
    );
  }
// =================================================
// MARK ALL NOTIFICATIONS READ
// =================================================
static Future<Map<String, dynamic>> markAllNotificationsRead(
    String token,
) async {
  final res = await http.post(
    Uri.parse("$baseUrl/mark-all-notifications-read.php"),
    headers: {
      "X-Auth-Token": token,
      "Accept": "application/json",
    },
  );

  return json.decode(res.body);
}

static Future<void> markNotificationUnread({
  required String token,
  required int notificationId,
}) async {
  await http.post(
    Uri.parse("$baseUrl/mark-notification-unread.php"),
    headers: {
      "X-Auth-Token": token,
      "Content-Type": "application/json",
    },
    body: json.encode({
      "id": notificationId,
    }),
  );
}

static Future<Map<String, dynamic>> deleteNotification({
  required String token,
  required int notificationId,
}) async {
  final res = await http.post(
    Uri.parse("$baseUrl/delete-notification.php"),
    headers: {
      "X-Auth-Token": token,
      "Content-Type": "application/json",
      "Accept": "application/json",
    },
    body: json.encode({
      "id": notificationId,
    }),
  );

  return json.decode(res.body);
}


  // =================================================
  // MARK NOTIFICATION READ
  // =================================================
  static Future<void> markNotificationRead({
    required String token,
    required int notificationId,
  }) async {
    await http.post(
      Uri.parse("$baseUrl/mark-notification-read.php"),
      headers: {
        "X-Auth-Token": token,
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: json.encode({
        "id": notificationId,
      }),
    );
  }
}
