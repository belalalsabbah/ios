import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../services/token_store.dart';
import 'main_navigation.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  bool loading = false;
  String? error;

  Future<void> login() async {
    if (userCtrl.text.trim().isEmpty ||
        passCtrl.text.trim().isEmpty) {
      setState(() => error = "يرجى إدخال اسم المستخدم وكلمة السر");
      return;
    }

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final res = await ApiService.login(
        username: userCtrl.text.trim(),
        password: passCtrl.text,
      );

      if (res["ok"] == true) {
        final token = res["token"].toString();
        await TokenStore.save(token);

        if (!mounted) return;

        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (_) => MainNavigation(token: token),
          ),
          (_) => false,
        );
        return;
      }

      // ❌ لا حساب → رسالة فقط
      if (res["error"] == "no_account") {
        setState(() {
          error = "لا يوجد حساب للتطبيق، يرجى الدخول من داخل الشبكة أولاً";
        });
        return;
      }

      setState(() {
        error = "اسم المستخدم أو كلمة السر غير صحيحة";
      });
    } catch (_) {
      setState(() => error = "فشل الاتصال بالسيرفر");
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text("تسجيل الدخول")),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextField(
                controller: userCtrl,
                decoration: const InputDecoration(
                  labelText: "اسم المستخدم",
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: passCtrl,
                obscureText: true,
                onSubmitted: (_) => login(),
                decoration: const InputDecoration(
                  labelText: "كلمة السر",
                  prefixIcon: Icon(Icons.lock),
                ),
              ),
              const SizedBox(height: 20),

              if (error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: loading ? null : login,
                  child: loading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text("دخول"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
