import 'package:flutter/material.dart';
import '../services/api_service.dart';
import 'notification_details_screen.dart';

class NotificationsScreen extends StatefulWidget {
  final String token;
  const NotificationsScreen({super.key, required this.token});

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  List<Map<String, dynamic>> items = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  // ================= API =================

  Future<void> load() async {
    setState(() => loading = true);

    try {
      final res = await ApiService.getNotifications(widget.token);
      if (res["ok"] == true) {
        setState(() {
          items = List<Map<String, dynamic>>.from(res["items"] ?? []);
          loading = false;
        });
      } else {
        loading = false;
      }
    } catch (_) {
      loading = false;
    }
  }

  bool isUnread(Map<String, dynamic> n) => n["is_read"] == 0;

  Future<void> markAsRead(int id) async {
    await ApiService.markNotificationRead(
      token: widget.token,
      notificationId: id,
    );
  }

  Future<void> markAsUnread(int id) async {
    await ApiService.markNotificationUnread(
      token: widget.token,
      notificationId: id,
    );
  }

  Future<void> deleteNotification(int id) async {
    await ApiService.deleteNotification(
      token: widget.token,
      notificationId: id,
    );
  }

  // ================= UI HELPERS =================

  Color getColor(String type) {
    switch (type) {
      case "expire_soon":
        return Colors.orange;
      case "expired":
        return Colors.red;
      case "renewed":
        return Colors.green;
      default:
        return Colors.blueGrey;
    }
  }

  IconData getIcon(String type) {
    switch (type) {
      case "expire_soon":
        return Icons.warning_amber_rounded;
      case "expired":
        return Icons.cancel;
      case "renewed":
        return Icons.check_circle;
      default:
        return Icons.notifications;
    }
  }

  // ================= BUILD =================

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("الإشعارات"),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: load,
            ),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : items.isEmpty
                ? const Center(child: Text("لا توجد إشعارات"))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: items.length,
                    itemBuilder: (_, i) {
                      final n = items[i];
                      final unread = isUnread(n);
                      final color = getColor(n["type"]);

                      return Dismissible(
                        key: ValueKey(n["id"]),
                        direction: DismissDirection.horizontal,

                        // 👉 Swipe يمين = مقروء
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          color: Colors.green,
                          child: const Icon(
                            Icons.done,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),

                        // 👈 Swipe يسار = حذف
                        secondaryBackground: Container(
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          color: Colors.red,
                          child: const Icon(
                            Icons.delete,
                            color: Colors.white,
                            size: 28,
                          ),
                        ),

                        confirmDismiss: (dir) async {
                          // 👉 مقروء
                          if (dir == DismissDirection.startToEnd) {
                            if (unread) {
                              await markAsRead(n["id"]);
                              setState(() => n["is_read"] = 1);
                            }
                            return false;
                          }

                          // 👈 حذف
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text("حذف الإشعار"),
                              content:
                                  const Text("هل أنت متأكد من حذف الإشعار؟"),
                              actions: [
                                TextButton(
                                  onPressed: () =>
                                      Navigator.pop(context, false),
                                  child: const Text("إلغاء"),
                                ),
                                ElevatedButton(
                                  onPressed: () =>
                                      Navigator.pop(context, true),
                                  child: const Text("حذف"),
                                ),
                              ],
                            ),
                          );

                          if (ok == true) {
                            await deleteNotification(n["id"]);
                            setState(() => items.removeAt(i));
                            return true;
                          }

                          return false;
                        },

                        child: InkWell(
                          onTap: () async {
                            if (unread) {
                              await markAsRead(n["id"]);
                              setState(() => n["is_read"] = 1);
                            }

                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) =>
                                    NotificationDetailsScreen(notification: n),
                              ),
                            );
                          },

                          // 👆 Long press = غير مقروء
                          onLongPress: () async {
                            if (!unread) {
                              await markAsUnread(n["id"]);
                              setState(() => n["is_read"] = 0);

                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text("تمت الإعادة كغير مقروء"),
                                  duration: Duration(seconds: 1),
                                ),
                              );
                            }
                          },

                          child: Card(
                            margin: const EdgeInsets.only(bottom: 12),
                            elevation: unread ? 4 : 0,
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: unread
                                    ? color.withOpacity(0.10)
                                    : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: unread
                                      ? color
                                      : Colors.grey.shade300,
                                  width: 1.2,
                                ),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    getIcon(n["type"]),
                                    size: 36,
                                    color: unread ? color : Colors.grey,
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                n["title"] ?? "",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: unread
                                                      ? FontWeight.bold
                                                      : FontWeight.normal,
                                                ),
                                              ),
                                            ),
                                            if (unread)
                                              Container(
                                                width: 10,
                                                height: 10,
                                                decoration: const BoxDecoration(
                                                  color: Colors.blue,
                                                  shape: BoxShape.circle,
                                                ),
                                              ),
                                          ],
                                        ),
                                        const SizedBox(height: 6),
                                        Text(n["body"] ?? ""),
                                        const SizedBox(height: 8),
                                        Text(
                                          n["created_at"] ?? "",
                                          style: TextStyle(
                                            color: Colors.grey.shade600,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
