import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../services/token_store.dart';
import 'main_navigation.dart';

class CreateAccountScreen extends StatefulWidget {
  final String name;
  final int subscriberId;

  const CreateAccountScreen({
    super.key,
    required this.name,
    required this.subscriberId,
  });

  @override
  State<CreateAccountScreen> createState() => _CreateAccountScreenState();
}

class _CreateAccountScreenState extends State<CreateAccountScreen> {
  final userCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  bool loading = false;
  String? error;

  Future<void> createAccount() async {
    final username = userCtrl.text.trim();
    final password = passCtrl.text;

    if (username.isEmpty || password.length < 6) {
      setState(() {
        error = "اسم المستخدم مطلوب وكلمة السر 6 أحرف على الأقل";
      });
      return;
    }

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final res = await ApiService.createAccount(
        subscriberId: widget.subscriberId,
        username: username,
        password: password,
      );

      if (res["ok"] == true && res["token"] != null) {
        final token = res["token"].toString();

        await TokenStore.save(token);

        if (!mounted) return;

        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(
            builder: (_) => MainNavigation(token: token),
          ),
          (_) => false,
        );
        return;
      }

      setState(() {
        error = res["error"] ?? "فشل إنشاء الحساب";
      });
    } catch (_) {
      setState(() {
        error = "فشل الاتصال بالسيرفر";
      });
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  @override
  void dispose() {
    userCtrl.dispose();
    passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text("إنشاء حساب")),
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "مرحبًا ${widget.name}",
                style: const TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20),

              TextField(
                controller: userCtrl,
                decoration: const InputDecoration(
                  labelText: "اسم المستخدم",
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 12),

              TextField(
                controller: passCtrl,
                obscureText: true,
                onSubmitted: (_) => createAccount(),
                decoration: const InputDecoration(
                  labelText: "كلمة السر",
                  prefixIcon: Icon(Icons.lock),
                  helperText: "6 أحرف على الأقل",
                ),
              ),
              const SizedBox(height: 20),

              if (error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Text(
                    error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: loading ? null : createAccount,
                  child: loading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : const Text("إنشاء الحساب"),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
