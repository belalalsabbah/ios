import 'package:flutter/material.dart';

import '../services/api_service.dart';
import '../services/token_store.dart';

import 'main_navigation.dart';
import 'login_screen.dart';
import 'create_account_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  String? error;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    try {
      final savedToken = await TokenStore.load();

      // 1️⃣ لو في Token محفوظ
      if (savedToken != null) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => MainNavigation(token: savedToken),
          ),
        );
        return;
      }

      // 2️⃣ فحص الشبكة / المشترك
      final res = await ApiService.getStatusAnonymous();

      if (res["ok"] != true) {
        _goInsideNetwork(res["message"]);
        return;
      }

      // 3️⃣ عنده حساب → تسجيل دخول
      if (res["has_account"] == true) {
        _goLogin();
        return;
      }

      // 4️⃣ أول مرة → إنشاء حساب
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => CreateAccountScreen(
            name: res["name"],
            subscriberId: res["subscriber_id"],
          ),
        ),
      );
    } catch (_) {
      setState(() => error = "فشل الاتصال بالسيرفر");
    }
  }

  // ================= NAVIGATION =================

  void _goLogin() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => const LoginScreen(),
      ),
    );
  }

  void _goInsideNetwork(String? message) {
    setState(() {
      error = message ??
          "أول تفعيل يجب أن يتم من داخل شبكة 2Net";
    });
  }

  // ================= UI =================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: error == null
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  CircularProgressIndicator(),
                  SizedBox(height: 12),
                  Text("2Net... جاري التحميل"),
                ],
              )
            : Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  error!,
                  textAlign: TextAlign.center,
                ),
              ),
      ),
    );
  }
}
